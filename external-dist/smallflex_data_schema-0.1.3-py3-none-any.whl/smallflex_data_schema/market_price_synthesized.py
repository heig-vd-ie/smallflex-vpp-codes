import patito as pt
import polars as pl
from datetime import datetime

from typing_extensions import Literal

from smallflex_data_schema._constraints import literal_constraint

MARKET = Literal["FCR-cap","aFRR-cap", "aFRR-act", "mFRR-cap", "mFRR-act", 'DA', 'IDA']
DIRECTION = Literal["pos", "sym", "neg"]

class MarketPriceSynthesized(pt.Model):
    timestamp: datetime = pt.Field(dtype=pl.Datetime(time_unit='us', time_zone='UTC'), description="Timestamp of the market price")
    scenario: int = pt.Field(dtype=pl.Int64, description="Scenario ID")
    market: MARKET = pt.Field(
        dtype=pl.Utf8, constraints=literal_constraint(pt.field, MARKET), description="Market type")
    direction: DIRECTION = pt.Field(
        dtype=pl.Utf8, constraints=literal_constraint(pt.field, DIRECTION), description="Direction of the market price")
    market_price: float = pt.Field(dtype=pl.Float64, description="Maximum value of the market price")

