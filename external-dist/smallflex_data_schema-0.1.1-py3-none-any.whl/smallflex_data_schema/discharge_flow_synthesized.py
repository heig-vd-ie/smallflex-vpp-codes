import patito as pt
import polars as pl
from datetime import datetime


from typing_extensions import Optional

UUID_REG = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$"

class DischargeFlowSynthesized(pt.Model):
    basin_fk: Optional[str] = pt.Field(dtype=pl.Utf8, pattern=UUID_REG, description="water basin uuid")
    timestamp: datetime = pt.Field(dtype=pl.Datetime(time_unit="us", time_zone="UTC"), description="Timestamp of the discharge flow")
    scenario: int = pt.Field(dtype=pl.Int64, description="Scenario ID")
    discharge_flow: float = pt.Field(dtype=pl.Float64, description="discharge flow in m^3/s")

