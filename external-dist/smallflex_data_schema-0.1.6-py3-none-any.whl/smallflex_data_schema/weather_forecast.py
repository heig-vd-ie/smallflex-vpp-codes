import patito as pt
import polars as pl
from datetime import datetime


from typing_extensions import Optional, Literal

from smallflex_data_schema._constraints import literal_constraint

# from data_federation.input_model._constraints import literal_constraint

TYPE = Literal["humidity","irradiation","precipitation","wind", "temperature"]
UUID_REG = r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$"

class WeatherForecast(pt.Model):
    timestamp: datetime = pt.Field(dtype=pl.Datetime(time_unit="us", time_zone="UTC"), description="Timestamp of the humidity")
    sub_basin: str = pt.Field(dtype=pl.Utf8, description="Sub-basin name")
    avg_height: int = pt.Field(dtype=pl.Int32, description="Start height in masl (end_height is 100m higher)")
    type: TYPE= pt.Field(
        dtype=pl.Utf8, constraints=literal_constraint(pt.field, TYPE), description="Type of weather forecast")
    rm00: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM00 value")
    rm01: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM01 value")
    rm02: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM02 value")
    rm03: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM03 value")
    rm04: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM04 value")
    rm05: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM05 value")
    rm06: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM06 value")
    rm07: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM07 value")
    rm08: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM08 value")
    rm09: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM09 value")
    rm10: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM10 value")
    rm11: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM11 value")
    rm12: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM12 value")
    rm13: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM13 value")
    rm14: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM14 value")
    rm15: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM15 value")
    rm16: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM16 value")
    rm17: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM17 value")
    rm18: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM18 value")
    rm19: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM19 value")
    rm20: list[float] = pt.Field(dtype=pl.List(pl.Float64), description="RM20 value")

